package com.subproblem.securityservice.dto;

public record ValidationResponse(
        Integer id,
        String email
) {
}
