package com.subproblem.gateway.dto;

public record UserResponseDto(
        Integer id,
        String email
) {
}
